import re
import string


def printsomething():
    print("Hello from python!")

def PrintMe(v):
    print("You sent me: " + v)
    return 100;

def SquareValue(v):
    return v * v


# print a list of items and their numerical frequency
def ListItemsWithFrequencies():
    # open the sample txt file and read it
    input_file = open('Project3_List.txt', 'r')

    # create a dictionary
    d = dict()

    for line in input_file:
        line = line.strip() # remove extra characters
        items = line.split(" ") # split the items in the file

        for item in items:
        #check to see if the item already exists in the dictionary and adjust count as appropriate
            if item in d:
                d[item] = d[item] + 1
            else:
                d[item] = 1

    for key in list(d.keys()):
        print(key, d[key])

    input_file.close()

# returns the frequency value of a specified item from the list
def SingleWordCount(user_word):
    # open the sample txt file and read it
    input_file = open('Project3_List.txt', 'r')

    # create a dictionary
    d = dict()

    # create a count variable
    count = 0

    for line in input_file:
        line = line.strip() # remove extra characters
        items = line.split(" ") # split the items in the file

        for item in items:
        #check to see if the item already exists in the dictionary and adjust count as appropriate
            if item in d:
                d[item] = d[item] + 1
            else:
                d[item] = 1
    return d[user_word]

    input_file.close()

# generates an outbound .dat file for the c++ code to use
def CreateOutboundFile():
    output_file = open('frequency.dat', 'w')

    # open the sample txt file and read it
    input_file = open('Project3_List.txt', 'r')

    # create a dictionary
    d = dict()

    for line in input_file:
        line = line.strip() # remove extra characters
        items = line.split(" ") # split the items in the file

        for item in items:
        #check to see if the item already exists in the dictionary and adjust count as appropriate
            if item in d:
                d[item] = d[item] + 1
            else:
                d[item] = 1

    for key, value in d.items():
        output_file.write('%s %s\n' %(key, value)) # write to the file

    input_file.close()
    output_file.close()
