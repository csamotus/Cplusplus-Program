#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <string>
#include <iomanip>
#include <stdexcept>
#include <fstream>

using namespace std;

/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("PythonCode");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python function you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

/*
Description:
	To call this function, pass the name of the Python function you wish to call and the integer parameter you want to send
Example:
	int x = callIntFunc("doublevalue",5);
Return:
	25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}

/*
Description:
	This function outputs a menu to the user of valid options for their input
*/
void userMenu() {
	cout << "1: Get a list of items purchased and how many times each item was purchased" << endl;
	cout << "2: Get the purchase frequency or a given item" << endl;
	cout << "3: Get a histogram of items purchased and the frequency" << endl;
	cout << "4: Exit" << endl;
	cout << "Enter your selection as a number 1, 2, 3, or 4" << endl;
}


/*
Description:
	Function nCharString prints the specified character(c) the given number of times(n).
*/
string nCharString(size_t n, char c) {
	string displayStr;
	unsigned int i;

	for (i = 0; i < n; ++i) {
		displayStr = displayStr + c;
	}

	return displayStr;
}

/*
Description:
	This function reads the .dat file, outputs each item name and a character depiction of the frequency value
*/
int readFile() {
	ifstream inputFile;
	string itemName;
	int itemCount;

	inputFile.open("frequency.dat");

	inputFile >> itemName;
	while (!inputFile.eof()) {
		while (!inputFile.fail()) {
			cout << itemName << " ";
			inputFile >> itemCount;
			cout << nCharString(itemCount, '*') << endl;
			inputFile >> itemName;
		}
	}

	inputFile.close();
}

int main()
{
	// sample code provided to validate Python connection
	//CallProcedure("printsomething");
	//cout << callIntFunc("PrintMe", "House") << endl;
	//cout << callIntFunc("SquareValue", 2) << endl;

	int userMenuSelection = 0;
	string userItem;


	// Loop until user quits
	while (userMenuSelection != 4) {
		userMenu();
		cin >> userMenuSelection;
	
		if (userMenuSelection == 1) {
			CallProcedure("ListItemsWithFrequencies"); // prints the list of items and numerical value frequency
		}
		else if (userMenuSelection == 2) {
			cout << "Enter the item you would like a count of" << endl;  // get the item the user wants the count of
			cin >> userItem;
			cout << callIntFunc("SingleWordCount", userItem) << endl; // returns the count of the specified item
		}
		else if (userMenuSelection == 3) {
			CallProcedure("CreateOutboundFile"); // creates a file with the items and numerical value frequency
			cout << readFile() << endl;
		}
		else if (userMenuSelection == 4) {
			break;
		}
		else {
			// validates user input when not one of the 4 available options
			do {
				if (cin.fail()) {
					cin.clear();
					cin.ignore(1, '\n');
				}
				cout << "Invalid selection.  Please enter 1, 2, 3 or 4" << endl;
				cin >> userMenuSelection;
			} while (cin.fail());
		}

	}

}

